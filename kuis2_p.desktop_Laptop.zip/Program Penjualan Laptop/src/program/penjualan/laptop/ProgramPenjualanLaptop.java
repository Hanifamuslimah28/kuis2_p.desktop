/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package program.penjualan.laptop;

/**
 *
 * @author Ardy Sendleep
 */
public class ProgramPenjualanLaptop {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Frame_penjualan_laptop Laund = new Frame_penjualan_laptop();
        Laund.setVisible(true);
    }
}
